import React from 'react'
import Header from '../Components/Header'
import TopHeader from '../Components/TopHeader'
import Vaccinated from '../Components/Vaccinated'
import Banner from '../Components/Banner'

function MainIndex() {
    return (
        <>
            
            <Banner />
            <Vaccinated />
        </>
    )
}

export default MainIndex