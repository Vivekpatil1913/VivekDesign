import React from 'react'

const VerifyCertificate = () => {
  return (
    <div>VerifyCertificate</div>
  )
}

export default VerifyCertificate